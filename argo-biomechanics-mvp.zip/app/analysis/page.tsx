import { VideoAnalysis } from "@/components/video-analysis"

export default function AnalysisPage() {
  return <VideoAnalysis />
}
