import { CoachAnalytics } from "@/components/coach-analytics"

export default function AnalyticsPage() {
  return <CoachAnalytics />
}
