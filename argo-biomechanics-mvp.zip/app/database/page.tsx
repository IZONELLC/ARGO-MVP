import { Database } from "@/components/database"

export default function DatabasePage() {
  return <Database />
}
